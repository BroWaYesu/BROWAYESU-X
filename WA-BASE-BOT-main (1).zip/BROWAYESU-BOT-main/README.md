# BRO WA YESU-X

A modular WhatsApp bot built using Node.js and Baileys — designed as the foundation for my YouTube tutorial series.  
With this base, you can easily add new commands every day and build your own full-featured WhatsApp bot from scratch.

💡 Features:
- Dynamic plugin system (just add .js command files)
- Auto reload (no restart needed)
- Owner & admin permissions
- Organized categories
- System tools and media commands
- Beginner-friendly code for learning

Each episode adds 1–2 new commands so you can follow along and grow your bot step by step — even if you don’t know how to code.

🧠 Need to edit the bot files?  
👉 contact BRO WA YESU +254746432359

👨‍💻 Base Project by BRO WA YESU CLI  
🎥 Tutorials & Upgrades by **BRO WA YESU**  
🔗 Library: [Baileys by @WhiskeySockets](https://github.com/WhiskeySockets/Baileys)


> "Do not wait to strike till the iron is hot; but make the iron hot by striking." – BRO WA YESU
> 
